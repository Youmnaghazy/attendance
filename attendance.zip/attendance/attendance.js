//fetch('').then((data)=>{
   // console.log(data);
  // return data.json();
//}).then((completedata)=>{   
//}).catch((err)=>{
  //  console.log(err);
//})
let btnGet = document.querySelector('button');
let mytable=document.querySelector('#table');
let attendance=[
    {
        id:'1', name:'Yomna',Email:'youmnaghazy2024@gmail.com',phone:'01004342299',nationalID:'30103191800182',university:'Cairo',college:'FCAI',level:'4',edit:'no',comment:'no'
        ,id:'3', name:'Y',Email:'youmnzy2024@gmail.com',phone:'01004342299',nationalID:'30103191800182',university:'Cairo',college:'FCAI',level:'4',edit:'no',comment:'no'
        ,id:'2', name:'Yo',Email:'youazy2024@gmail.com',phone:'0100434299',nationalID:'30103191800182',university:'Cairo',college:'FCAI',level:'4',edit:'no',comment:'no'
        ,id:'6', name:'Yoa',Email:'youmnagha4@gmail.com',phone:'01004342299',nationalID:'30103191800182',university:'Cairo',college:'FCAI',level:'4',edit:'no',comment:'no'
        ,id:'13', name:'Yoa',Email:'youmnag024@gmail.com',phone:'01004342299',nationalID:'30103191800182',university:'Cairo',college:'FCAI',level:'4',edit:'no',comment:'no'
    }
]
let headers =['id','name','Email','phone','nationalID','university','college','level','edit',comment]
btnGet.addEventListener('click',()=>{
    let table=document.createElement('table');
    let headerRow= document.createElement('tr');

    headers.forEach(headerText=>{
        let header=document.createElement('th');
        let textNode=document.createTextNode(headerText);
        cell.appendChild(textNode);
        row.appendChild(cell)
    })
    table.appendChild(headerRow);
    mytable.appendChild(table)
})